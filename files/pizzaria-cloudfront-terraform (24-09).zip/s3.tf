locals {
  name_prefix   = "${var.project_name}-${var.environment}"
  has_domain    = var.domain_name != ""
  bucket_name   = "${local.name_prefix}-frontend"
}

# Bucket que guarda o build estático (dist/) do React.
# É privado: só o CloudFront consegue ler, via Origin Access Control.
resource "aws_s3_bucket" "frontend" {
  bucket = local.bucket_name
  tags   = var.tags

  # Permite que "terraform destroy" apague o bucket mesmo com objetos dentro
  # (incluindo versões antigas, já que o versionamento está habilitado).
  # Sem isso, todo destroy trava com BucketNotEmpty porque os uploads feitos
  # via s3 sync/null_resource não são rastreados pelo Terraform.
  force_destroy = true
}

resource "aws_s3_bucket_public_access_block" "frontend" {
  bucket = aws_s3_bucket.frontend.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_versioning" "frontend" {
  bucket = aws_s3_bucket.frontend.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "frontend" {
  bucket = aws_s3_bucket.frontend.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

# Origin Access Control: permite que só esta distribuição CloudFront
# específica leia objetos do bucket (substitui o antigo OAI).
resource "aws_cloudfront_origin_access_control" "frontend" {
  name                              = "${local.name_prefix}-oac"
  origin_access_control_origin_type = "s3"
  signing_behavior                  = "always"
  signing_protocol                  = "sigv4"
}

# Política do bucket: nega tudo, exceto leitura vinda da distribuição CloudFront abaixo.
resource "aws_s3_bucket_policy" "frontend" {
  bucket = aws_s3_bucket.frontend.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "AllowCloudFrontServicePrincipalReadOnly"
        Effect    = "Allow"
        Principal = { Service = "cloudfront.amazonaws.com" }
        Action    = "s3:GetObject"
        Resource  = "${aws_s3_bucket.frontend.arn}/*"
        Condition = {
          StringEquals = {
            "AWS:SourceArn" = aws_cloudfront_distribution.frontend.arn
          }
        }
      }
    ]
  })
}
