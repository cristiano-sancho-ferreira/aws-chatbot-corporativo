output "s3_bucket_name" {
  description = "Nome do bucket S3 onde o build (dist/) deve ser enviado"
  value       = aws_s3_bucket.frontend.id
}

output "cloudfront_distribution_id" {
  description = "ID da distribuição CloudFront (usado para invalidar o cache no deploy)"
  value       = aws_cloudfront_distribution.frontend.id
}

output "cloudfront_domain_name" {
  description = "Domínio padrão do CloudFront (*.cloudfront.net)"
  value       = aws_cloudfront_distribution.frontend.domain_name
}

output "site_url" {
  description = "URL final do site"
  value       = local.has_domain ? "https://${var.domain_name}" : "https://${aws_cloudfront_distribution.frontend.domain_name}"
}

output "cognito_user_pool_id" {
  description = "VITE_COGNITO_USER_POOL_ID — cole no .env do frontend"
  value       = var.manage_cognito_user_pool ? aws_cognito_user_pool.users[0].id : null
}

output "cognito_user_pool_client_id" {
  description = "VITE_COGNITO_CLIENT_ID — cole no .env do frontend"
  value       = var.manage_cognito_user_pool ? aws_cognito_user_pool_client.spa[0].id : null
}
