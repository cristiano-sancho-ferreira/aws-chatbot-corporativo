variable "project_name" {
  description = "Nome usado como prefixo dos recursos (ex.: mamapizzaria)"
  type        = string
  default     = "pizzaria-chat"
}

variable "environment" {
  description = "Nome do ambiente (prod, staging, dev)"
  type        = string
  default     = "prod"
}

variable "aws_region" {
  description = "Região AWS onde o bucket S3 será criado"
  type        = string
  default     = "us-east-1"
}

variable "domain_name" {
  description = "Domínio customizado do site (ex.: chat.mamapizzaria.com.br). Deixe vazio para usar apenas o domínio padrão do CloudFront (*.cloudfront.net)."
  type        = string
  default     = ""
}

variable "create_dns_record" {
  description = "Se true, cria o registro Route 53 apontando o domínio para o CloudFront. Exige domain_name e hosted_zone_id preenchidos."
  type        = bool
  default     = false
}

variable "hosted_zone_id" {
  description = "ID da Hosted Zone no Route 53 (necessário só se create_dns_record = true)"
  type        = string
  default     = ""
}

variable "price_class" {
  description = "Price class do CloudFront (PriceClass_100 = só América do Norte/Europa, mais barato; PriceClass_All = cobertura global)"
  type        = string
  default     = "PriceClass_100"
}

variable "enable_waf" {
  description = "Se true, cria uma Web ACL do WAFv2 com regras gerenciadas da AWS e associa ao CloudFront"
  type        = bool
  default     = true
}

variable "frontend_path" {
  description = "Caminho (relativo a esta pasta terraform/) do projeto React do frontend"
  type        = string
  default     = "../pizzaria-chat-frontend"
}

variable "auto_deploy" {
  description = "Se true, o 'terraform apply' já builda o React, sincroniza com o S3 e invalida o CloudFront. Se false, você builda e sobe o frontend manualmente (ver README)."
  type        = bool
  default     = true
}

variable "manage_cognito_user_pool" {
  description = "Se true, este Terraform cria o Cognito User Pool com self sign-up habilitado. Se você já tem um User Pool configurado (ex.: criado manualmente), defina como false e preencha var.existing_user_pool_id / existing_user_pool_client_id só como referência, se quiser."
  type        = bool
  default     = true
}

variable "cognito_min_password_length" {
  description = "Tamanho mínimo de senha exigido no cadastro"
  type        = number
  default     = 8
}

variable "ws_url" {
  description = "URL do WebSocket do backend (API Gateway), ex.: wss://xxxx.execute-api.us-east-1.amazonaws.com/prod. Vem de outro Terraform/stack, fora deste projeto."
  type        = string
  default     = ""
}

variable "assistant_name" {
  description = "Nome exibido no cabeçalho do chat"
  type        = string
  default     = "Assistente virtual"
}

variable "tags" {
  description = "Tags aplicadas a todos os recursos"
  type        = map(string)
  default = {
    Project = "pizzaria-chat-frontend"
  }
}
