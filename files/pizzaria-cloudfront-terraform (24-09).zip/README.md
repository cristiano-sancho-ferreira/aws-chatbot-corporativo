# Infraestrutura — S3 + CloudFront (Terraform)

Cria a parte de hosting estático do diagrama: bucket S3 privado, CloudFront
na frente (com Origin Access Control), certificado ACM opcional e uma Web
ACL do WAFv2 com regras gerenciadas da AWS.

> Terraform não foi executado aqui (sandbox sem acesso ao registro do
> HashiCorp) — a sintaxe HCL de todos os arquivos foi validada, mas rode
> `terraform validate` na sua máquina antes do `apply`.

## Arquivos

| Arquivo                     | O que cria                                              |
|------------------------------|----------------------------------------------------------|
| `versions.tf`                | Provider AWS (+ alias `us_east_1` para ACM/WAF)          |
| `variables.tf`                | Todas as variáveis configuráveis                          |
| `s3.tf`                       | Bucket privado + Origin Access Control                    |
| `acm.tf`                      | Certificado TLS (só se `domain_name` for preenchido)      |
| `waf.tf`                      | Web ACL com regras gerenciadas + rate limit                |
| `cloudfront.tf`                | Distribuição CDN, com fallback de SPA (403/404 → index.html) |
| `cognito.tf`                   | Cognito User Pool com self sign-up + App Client do SPA        |
| `route53.tf`                   | Registro DNS (só se `create_dns_record = true`)             |
| `deploy.tf`                     | Gera o `.env`, builda o React, sincroniza com S3 e invalida o CloudFront (opcional) |
| `outputs.tf`                   | IDs e URLs para usar no deploy                              |

## Cognito — cadastro de usuários (self sign-up)

Por padrão (`manage_cognito_user_pool = true`), este Terraform já cria o
User Pool com **cadastro público habilitado**: qualquer pessoa pode criar
conta pela tela do site (`Criar conta` → recebe código por e-mail →
confirma → faz login). Isso é o que a tela `SignUpScreen`/`ConfirmScreen`
do frontend espera.

Detalhes importantes:
- O e-mail de verificação sai pelo remetente padrão do Cognito
  (`COGNITO_DEFAULT`), que tem um **limite baixo de envios por dia** (na
  prática, poucas dezenas). Para um volume maior de cadastros, troque
  `email_configuration.email_sending_account` para `DEVELOPER` e configure
  um domínio verificado no SES — me avise se quiser que eu monte essa parte.
- Se você já tem um User Pool criado (manualmente ou em outro Terraform),
  defina `manage_cognito_user_pool = false` no `terraform.tfvars` e garanta
  nele mesmo que `allow_admin_create_user_only = false` (senão a tela de
  cadastro do site recebe erro "not authorized").
- Preencha `ws_url` no `terraform.tfvars` com a URL do WebSocket do backend
  assim que o outro stack (API Gateway/Lambdas/Bedrock) estiver criado —
  ela entra automaticamente no `.env` gerado.

## Preenchimento automático do `.env` do frontend

Com `auto_deploy = true` (padrão), o Terraform escreve
`../pizzaria-chat-frontend/.env` sozinho, usando os outputs reais do
Cognito criado (`cognito_user_pool_id`, `cognito_user_pool_client_id`) mais
`ws_url` e `assistant_name` do `terraform.tfvars`. Isso substitui qualquer
`.env` manual que você tenha editado ali — se preferir gerenciar o `.env` à
mão, use `auto_deploy = false` e preencha os outputs manualmente (comando
no final da seção "Deploy" abaixo).

## 1. Configurar variáveis

```bash
cp terraform.tfvars.example terraform.tfvars
```

Cenários possíveis:

**Sem domínio próprio ainda** (usa só `*.cloudfront.net`) — é o padrão do
`terraform.tfvars.example`, não precisa mudar nada.

**Com domínio e zona no Route 53:**
```hcl
domain_name       = "chat.suapizzaria.com.br"
create_dns_record = true
hosted_zone_id    = "Z0123456789ABCDEF"
```
Nesse caso o Terraform cria o certificado, valida via DNS automaticamente e
já cria o registro apontando pro CloudFront — tudo em um único `apply`.

**Com domínio em outro provedor de DNS (fora da AWS):**
```hcl
domain_name       = "chat.suapizzaria.com.br"
create_dns_record = false
```
Aqui você precisa validar o certificado manualmente:
1. `terraform apply -target=aws_acm_certificate.frontend`
2. Pegue os registros de validação com `terraform output` ou no console ACM
   e crie-os no seu provedor de DNS.
3. Espere o certificado ficar "Issued" no console ACM.
4. Rode `terraform apply` normalmente para criar o resto (CloudFront já
   consegue usar o certificado validado).
5. Aponte um CNAME/ALIAS do seu domínio para a saída `cloudfront_domain_name`.

## 2. Deploy

```bash
terraform init
terraform plan
terraform apply
```

Por padrão (`auto_deploy = true`), o próprio `apply` já builda o React e
publica o site, em 3 passos encadeados definidos em `deploy.tf`:

1. `null_resource.build_frontend` → roda `npm install && npm run build`
   dentro de `var.frontend_path` (padrão: `../pizzaria-chat-frontend`)
2. `null_resource.sync_s3` → `aws s3 sync .../dist s3://<bucket> --delete`
3. `null_resource.invalidate_cloudfront` → invalida o cache do CloudFront

Esses três só re-executam quando o código do frontend muda de verdade: o
hash de `src/**`, `public/**`, `package.json`, `package-lock.json`,
`vite.config.ts` e `index.html` fica salvo como trigger, então um
`terraform apply` sem mudanças no frontend não builda nem sincroniza de novo.

Se preferir buildar/publicar fora do Terraform (ex.: numa pipeline de CI
separada), defina `auto_deploy = false` no `terraform.tfvars` e faça manualmente:

```bash
BUCKET=$(terraform output -raw s3_bucket_name)
DIST_ID=$(terraform output -raw cloudfront_distribution_id)

cd ../pizzaria-chat-frontend
npm install && npm run build
aws s3 sync dist/ s3://$BUCKET --delete
aws cloudfront create-invalidation --distribution-id $DIST_ID --paths "/*"
```

> Nota sobre `local-exec`: os comandos rodam na máquina que executa o
> `terraform apply` (seu computador ou o runner de CI), então ela precisa
> ter `npm`, `node` e a `aws cli` configurada com credenciais válidas.

## Notas de segurança / custo

- O bucket é 100% privado — só a distribuição CloudFront específica (via
  Origin Access Control com condição `AWS:SourceArn`) consegue ler os
  objetos, mesmo que alguém descubra o nome do bucket.
- `price_class = "PriceClass_100"` cobre só América do Norte e Europa, que é
  mais barato. Troque para `PriceClass_All` se seus clientes acessarem de
  outras regiões (ex.: para acessos vindos de fora do Brasil).
- O WAF vem com `AWSManagedRulesCommonRuleSet`, `AWSManagedRulesKnownBadInputsRuleSet`
  e um rate limit de 2000 requisições/5min por IP. Esses managed rule groups
  têm custo por requisição avaliada — ajuste ou desative (`enable_waf = false`)
  se o tráfego esperado for muito pequeno no início.
- O WebSocket do chat (API Gateway) **não** faz parte deste Terraform — ele
  fica no backend (Lambdas, DynamoDB, Bedrock AgentCore) do seu diagrama.
  Se quiser, posso montar o Terraform dessa parte também.
