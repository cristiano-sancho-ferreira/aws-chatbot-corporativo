# Certificado só é criado se um domínio customizado for informado.
# Precisa estar em us-east-1 porque é usado pelo CloudFront.
resource "aws_acm_certificate" "frontend" {
  count = local.has_domain ? 1 : 0

  provider          = aws.us_east_1
  domain_name       = var.domain_name
  validation_method = "DNS"
  tags              = var.tags

  lifecycle {
    create_before_destroy = true
  }
}

# Registro DNS de validação do certificado (só criado se você também
# gerencia a zona no Route 53 e habilitou create_dns_record).
resource "aws_route53_record" "cert_validation" {
  for_each = local.has_domain && var.create_dns_record ? {
    for dvo in aws_acm_certificate.frontend[0].domain_validation_options : dvo.domain_name => {
      name   = dvo.resource_record_name
      record = dvo.resource_record_value
      type   = dvo.resource_record_type
    }
  } : {}

  zone_id         = var.hosted_zone_id
  name            = each.value.name
  type            = each.value.type
  records         = [each.value.record]
  ttl             = 60
  allow_overwrite = true
}

resource "aws_acm_certificate_validation" "frontend" {
  count = local.has_domain && var.create_dns_record ? 1 : 0

  provider                = aws.us_east_1
  certificate_arn         = aws_acm_certificate.frontend[0].arn
  validation_record_fqdns = [for r in aws_route53_record.cert_validation : r.fqdn]
}
