# Só cria o registro se você tiver a zona no Route 53 e pediu explicitamente
# (create_dns_record = true). Caso seu domínio esteja em outro provedor de DNS,
# deixe como false e aponte manualmente um CNAME/ALIAS para o domínio do CloudFront
# (saída cloudfront_domain_name).
resource "aws_route53_record" "frontend" {
  count = local.has_domain && var.create_dns_record ? 1 : 0

  zone_id = var.hosted_zone_id
  name    = var.domain_name
  type    = "A"

  alias {
    name                   = aws_cloudfront_distribution.frontend.domain_name
    zone_id                = aws_cloudfront_distribution.frontend.hosted_zone_id
    evaluate_target_health = false
  }

  depends_on = [aws_acm_certificate_validation.frontend]
}
