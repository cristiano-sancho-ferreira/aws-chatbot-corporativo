terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    local = {
      source  = "hashicorp/local"
      version = "~> 2.5"
    }
  }
}

# Provider principal, na região onde você normalmente trabalha
provider "aws" {
  region = var.aws_region
}

# CloudFront exige que certificados ACM e Web ACLs do WAF usados por ele
# existam na região us-east-1, independente de onde está o resto da stack.
provider "aws" {
  alias  = "us_east_1"
  region = "us-east-1"
}
